import tkinter as prim
from tkinter import *
from tkinter import ttk

data=[]
par=[]
width = 5

root=Tk()

f = open('recipe_name.txt','r')
temp = f.readline()
f.close()

photo = prim.PhotoImage(file= r"images/"+temp+".gif")
cv = prim.Canvas(root,bg='white',bd='0')
cv.pack(side='top', fill='both', expand='yes')
cv.create_image(0, 0, image=photo, anchor='nw')

det = LabelFrame(root, text="Ingredients",bd='3')
det.pack(fill="both", expand="yes")

det1 = LabelFrame(root, text="Cooking Process",bd='3')
det1.pack(fill="both", expand="yes")

f = open('recipes/'+temp+'.txt','r')
temp = f.readline()
data=temp.split(',')
f.close()
height = len(data)
j=0
print(data)
for s in data:
    print(s)
    if(j==len(data)-1):
        b = Label(det1, text=s)
        b.pack(side=LEFT)
    else:
        b = Label(det, text=s)
        b.grid(row=j, column=1)
        j=j+1

root.mainloop()
