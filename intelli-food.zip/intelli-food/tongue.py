import tkinter as prim
from tkinter import *

f = open('taste.txt','r')
temp1 = f.readline()
f.close()

root=Tk()
root.title("Affected Zone")
root.geometry("%dx%d+%d+%d" % (250, 350, 100, 30))

photo = prim.PhotoImage(file= r"images/tongue.gif")
cv = prim.Canvas(root,bg='white',bd='0')
cv.pack(side='top', fill='both', expand='yes')
cv.create_image(0, 0, image=photo, anchor='nw')

if(temp1=="sweet"):
    coord = 120, 290, 150, 320
    arc = cv.create_arc(coord, start=0, extent=359, fill="blue")
elif(temp1=="salty"):
    coord = 120, 290, 150, 320
    arc = cv.create_arc(coord, start=0, extent=359, fill="blue")
elif(temp1=="bitter"):
    coord = 120, 190, 150, 220
    arc = cv.create_arc(coord, start=0, extent=359, fill="blue")
elif(temp1=="sour"):
    coord = 80, 230, 100, 250
    arc = cv.create_arc(coord, start=0, extent=359, fill="blue")
    coord = 140, 230, 160, 250
    arc = cv.create_arc(coord, start=0, extent=359, fill="blue")
    
root.mainloop()
